﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;

namespace _14
{
    public partial class Form1 : Form
    {
       

        public Form1()
        {
            InitializeComponent();
        }
        //1 zadanie
        private void button1_Click(object sender, EventArgs e)
        {
            Stack<int> stack = new Stack<int>();
            stack.Clear();
            if (textBox1.Text != "")
            {
                int n = Convert.ToInt32(textBox1.Text);
                for (int i = 1; i <= n; i++)
                {
                    stack.Push(i);
                }

            }
            else MessageBox.Show("Поле пустое, введите число");           
            if (stack.Count>0)
            {
                listBox1.Items.Add($"n={textBox1.Text}");
                listBox1.Items.Add($"размерность cтека : {stack.Count}");
                listBox1.Items.Add($"верхний элемент cтека : {stack.Peek()}");
                listBox1.Items.Add($"содержимое cтека : {string.Join(",",stack)}");
                stack.Clear();
                listBox1.Items.Add($"новая размерность cтека : {stack.Count}");
            }
            else MessageBox.Show("стек пуст");
           

        }
       //4zadanie
        private void button2_Click(object sender, EventArgs e)
        {
            Queue<Pp> people = new Queue<Pp>();
            string file = "file.txt";
            if (!File.Exists(file))
            {
                MessageBox.Show("Файл не найден", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                string[] lines = File.ReadAllLines(file);
                Pp h = new Pp("", "", "", 0, 0);
                foreach (string line in lines)
                {
                    string[] chel = line.Split(' ');
                    string inname = chel[0];
                    h.set_inname(inname);
                    string name = chel[1];
                    h.set_name(name);
                    string otch = chel[2];
                    h.set_otch(otch);
                    int age = Convert.ToInt32(chel[3]);
                    h.set_age(age);
                    double weidth = Convert.ToDouble(chel[4]);
                    h.set_weidth(weidth);
                    string f = $"{h.get_inname()} {h.get_name()} {h.get_otch()} {h.get_age()} {h.get_weidth()}\n\n\n";
                    listBox2.Items.Add(f);
                    people.Enqueue(new Pp(inname, name, otch, age, weidth));
                    var b = from p in people
                            where Convert.ToInt32(p.get_age()) < 40
                            select p;
                    foreach (var a in b)
                    {
                        string f1 = $"ФИО: {a.get_inname()}  {a.get_name()}  {a.get_otch()}  \nВозраст:  {a.get_age()} \n Вес: {a.get_weidth()}\n\n\n";
                        listBox3.Items.Add(f1);
                    }
                }
            }
        }
        ///3zadanie
        private void button3_Click(object sender, EventArgs e)
        {
            Queue<int> p = new Queue<int>();
            p.Clear();
            if (textBox2.Text != "")
            {
                int n = Convert.ToInt32(textBox2.Text);
                for (int i = 1; i <= n; i++)
                {
                    p.Enqueue(i);
                }

            }
            else MessageBox.Show("Поле пустое, введите число");
            if (p.Count > 0)
            {
                listBox4.Items.Add($"n={textBox2.Text}");
                listBox4.Items.Add($"размерность очереди : {p.Count}");
                listBox4.Items.Add($"верхний элемент очереди : {p.Peek()}");
                listBox4.Items.Add($"содержимое очереди : {string.Join(",", p)}");
                p.Clear();
                listBox4.Items.Add($"новая размерность очереди : {p.Count}");
            }
            else MessageBox.Show("стек пуст");

        }

        ///5zadanie
        private void button4_Click(object sender, EventArgs e)
        {
            Queue<Pp> people = new Queue<Pp>();
            string file1 = "file1.txt";
            string file2 = "file2.txt";
            if ((!File.Exists(file1))&& (!File.Exists(file2)))
            {
                MessageBox.Show("Файл не найден", "Ошибка", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                string[] lines1 = File.ReadAllLines(file1);
                string[] lines2 = File.ReadAllLines(file2);
                Pp h = new Pp("", "", "", 0, 0);
                foreach (string line in lines1)
                {
                    string[] chel1 = line.Split(' ');
                    string inname = chel1[0];
                    h.set_inname(inname);
                    string name = chel1[1];
                    h.set_name(name);
                    string otch = chel1[2];
                    h.set_otch(otch);
                    int age = 0;
                    h.set_age(age);
                    double weidth = 0;
                    h.set_weidth(weidth);
                    string f = $"{h.get_inname()} {h.get_name()} {h.get_otch()} {h.get_age()} {h.get_weidth()}\n\n\n";
                    listBox6.Items.Add(f);
                    people.Enqueue(new Pp(inname, name, otch, age, weidth));
                }
                Pp hh = new Pp("", "", "", 0, 0);
                foreach (string line11 in lines2)
                {
                    string[] chel12 = line11.Split(' ');
                    string inname = "";
                    hh.set_inname(inname);
                    string name = "";
                    hh.set_name(name);
                    string otch ="";
                    hh.set_otch(otch);
                    int age = Convert.ToInt32(chel12[0]);
                    hh.set_age(age);
                    double weidth = Convert.ToDouble(chel12[1]);
                    hh.set_weidth(weidth);
                    string ff = $"{hh.get_inname()} {hh.get_name()} {hh.get_otch()} {hh.get_age()} {hh.get_weidth()}\n\n\n";
                    listBox6.Items.Add(ff);
                    people.Enqueue(new Pp(inname, name, otch, age, weidth));                  
                }
                /* foreach (string line2 in lines2)
                 {
                     string[] chel2 = line2.Split(' ');
                     int age = Convert.ToInt32(chel2[0]);
                     h.set_age(age);
                     double weidth = Convert.ToDouble(chel2[1]);
                     h.set_weidth(weidth);
                     *//*people.Enqueue(new Pp("", "", "", age, weidth));*//*
                 }*/


                /*h.set_age(age);
                double weidth = Convert.ToDouble(chel[4]);
                h.set_weidth(weidth);
                string f = $"{h.get_inname()} {h.get_name()} {h.get_otch()} {h.get_age()} {h.get_weidth()}\n\n\n";
                listBox6.Items.Add(f);
                people.Enqueue(new Pp(inname, name, otch, age, weidth));*/
                /*var b = from p in people
                        where Convert.ToInt32(p.get_age()) < 40
                        select p;
                foreach (var a in b)
                {
                    string f1 = $"ФИО: {a.get_inname()}  {a.get_name()}  {a.get_otch()}  \nВозраст:  {a.get_age()} \n Вес: {a.get_weidth()}\n\n\n";
                    listBox3.Items.Add(f1);
                }*/

            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            StreamWriter f = File.CreateText("t.txt");
            int c1 = 0, c2 = 0;
            if (textBox3.Text != "")
            {
                f.WriteLine(textBox3.Text);
                f.Close();
                if (File.Exists("t.txt"))
                {
                    if (File.Exists("t1.txt"))
                    {
                        StreamReader s = new StreamReader("t.txt");
                        string p = s.ReadLine();
                        foreach (char z in p)
                        {
                            if (z == ')') c1++;
                            else if (z == '(') c2++;
                        }
                        if (c1 == c2) listBox7.Items.Add($"{textBox3.Text} скобки сбалансированы");
                        else if (c1 > c2)
                        {
                            listBox7.Items.Add($"{textBox3.Text} скобки не сбалансированы.");
                            listBox7.Items.Add($"Лишняя скобка ) на позиции  {p.LastIndexOf(")")}");
                            StreamWriter  n= new StreamWriter("t1.txt");
                            n.WriteLine("(" + textBox3.Text);
                            n.Close();
                        }
                        else
                        {
                            listBox7.Items.Add($"В выражениии {textBox3.Text} скобки не сбалансированы.");
                            listBox7.Items.Add($"Лишняя скобка ( на позиции  {p.IndexOf("(")}");
                            StreamWriter n = new StreamWriter("t1.txt");
                            n.WriteLine(textBox3.Text + ")");
                            n.Close();
                        }
                    }
                    else MessageBox.Show(" Ошибка");
                }
                else MessageBox.Show( "Ошибка");
            }
            else MessageBox.Show("Ошибка");

        }
    }
}
